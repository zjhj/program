import React from 'react';
import './index.css';

function App() {
  return (
    <div><h1 className={'h1_1'}>Hello React!</h1></div>
  );
}

export default App;
