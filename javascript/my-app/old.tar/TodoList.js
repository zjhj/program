constructor(props) {
	super(props);
	this.state = {
		inputValue: '',
		list: []
	}
	this.handleInputChange = this.handleInputChange.bind(this);
	this.handleBtnClick = this.handleBtnClick.bind(this);
	this.handleItemDelete = this.handleItemDelete.bind(this);
}
